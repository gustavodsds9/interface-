﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio6
{
    internal class Milhas
    {
        public double milhas;
        public double converterMilhas()
        {
            return (this.milhas * (1852 / 1000.0)); 
        }
    }
}
