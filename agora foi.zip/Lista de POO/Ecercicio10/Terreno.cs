﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecercicio10
{
    internal class Terreno
    {
        public double b,a;
        public string calcularTerreno()
        {
            double area = this.a * this.b;
            if (area > 100) {
                return "A área é: " + area + " Terreno grande";
            }
            else return "A área é: " + area + " Terreno pequeno";

        }
    }
}
