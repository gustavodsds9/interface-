﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            Dolar dolar = new Dolar();
            dolar.cotacao =Convert.ToDouble(textBoxCot.Text);
            dolar.valor = Convert.ToDouble(textBoxDol.Text);
            labelResultado.Text ="R$ "+Convert.ToString(dolar.converter()); 
        }
    }
}
