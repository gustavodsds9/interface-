﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio7
{
    internal class Dolar
    {
        public double cotacao, valor;
        public double converter()
        {
            return this.cotacao * this.valor;
        }
    }
}
