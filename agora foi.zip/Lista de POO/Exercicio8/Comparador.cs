﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio8
{
    internal class Comparador
    {
        public double v1, v2;
       public string comparar()
        {
            if (this.v1 > this.v2)
            {
                return "O maior é " + this.v1;
            }
            else if (this.v2 > this.v1) {
                return "O maior é " + this.v2;
            }
            else
            {
                return this.v1+" e "+ this.v2 +" são iguais";
            }
        }
    }
}
