﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonComparar_Click(object sender, EventArgs e)
        {
            Comparador comp=new Comparador();
            comp.v1=Convert.ToDouble(textBoxV1.Text);
            comp.v2 = Convert.ToDouble(textBoxV2.Text);
            labelResultado.Text=comp.comparar();
        }
    }
}
