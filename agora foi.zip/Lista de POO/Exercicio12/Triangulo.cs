﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio12
{
    internal class Triangulo
    {
        public double v1, v2, v3;
        public string descobrirTriangulo()
        {
            if (this.v1 + this.v2 > this.v3 && this.v1 + this.v3 > this.v2 && this.v2 + this.v3 > this.v1)
            {
                if (this.v1 == this.v2 && this.v2 == this.v3)
                {
                    return "Triângulo Equilátero";
                }
                else if (this.v1 == this.v2 || this.v1 == this.v3 || this.v2 == this.v3)
                {
                    return "Triângulo Isósceles";
                }
                else
                {
                    return "Triângulo Escaleno";
                }
            }
            else
            {
                return "Não forma um triângulo";
            }
        }
    }
}
