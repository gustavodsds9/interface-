﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            Triangulo triangulo=new Triangulo();
            triangulo.v1 = Convert.ToDouble(textBoxV1.Text);
            triangulo.v2 = Convert.ToDouble(textBoxV2.Text);
            triangulo.v3 = Convert.ToDouble(textBoxV3.Text);
            labelResultado.Text = triangulo.descobrirTriangulo();

        }
    }
}
