﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            PesoAltura ideal = new PesoAltura();
            ideal.altura = Convert.ToDouble(textBoxAltura.Text);
            ideal.peso=Convert.ToDouble(textBoxPeso.Text);
            labelResultado.Text = ideal.calcularPesoIdeal();
        }
    }
}
