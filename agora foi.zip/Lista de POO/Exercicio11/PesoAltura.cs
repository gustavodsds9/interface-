﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio11
{
    internal class PesoAltura
    {
        public double peso, altura;
        public string calcularPesoIdeal()
        {
            double relacao = (this.peso / (Math.Pow(this.altura, 2)));
            if (relacao < 20) return "Abaixo do peso";
            else if (relacao <= 20 || relacao < 25) return "Peso ideal ";
            else return "Acima do peso ";
        }
    }
}
