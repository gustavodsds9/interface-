﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio1
{
    internal class Quadrado
    {
        public double aresta;

        public double calcularArea()
        {
            return (this.aresta*this.aresta);
        }
    }
}
