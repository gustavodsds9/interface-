﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio13
{
    internal class TrianguloRetangulo
    {
        public double l1, l2, l3;
        public string descobrirTrianguloRetangulo(){

            double maiorValor, somaQuadradosCatetos;

            if (this.l1 > this.l2 && this.l1 > this.l3)
            {
                maiorValor = this.l1;
                somaQuadradosCatetos = (this.l2 * this.l2) + (this.l3 * this.l3);
            }
            else if (this.l2 > this.l1 && this.l2 > this.l3)
            {
                maiorValor = this.l2;
                somaQuadradosCatetos = (this.l1 * this.l1) + (this.l3 * this.l3);
            }
            else
            {
                maiorValor = this.l3;
                somaQuadradosCatetos = (this.l1 * this.l1) + (this.l2 * this.l2);
            }

            if(maiorValor * maiorValor == somaQuadradosCatetos)
            {
                return "Forma um triangulo retangulo";
            }
            return "Não um forma triangulo retangulo";
        }
    }
}
