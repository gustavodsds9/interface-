﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TrianguloRetangulo triangulo = new TrianguloRetangulo();
            triangulo.l1 = Convert.ToDouble(textBoxL1.Text);
            triangulo.l2 = Convert.ToDouble(textBoxL2.Text);
            triangulo.l3 = Convert.ToDouble(textBoxL3.Text);
            labelResultado.Text = triangulo.descobrirTrianguloRetangulo();
        }
    }
}
